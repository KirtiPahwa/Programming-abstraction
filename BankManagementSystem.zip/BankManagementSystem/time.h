class Time
{
public:
    int date;
    int month;
    int year;
};
